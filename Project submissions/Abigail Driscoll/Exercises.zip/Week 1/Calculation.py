print(2 + 10 * 2 - 10 / 2)  # this calculation does 2 + 20(10*2) - 5(10/2) = 17
print(((2 + 10) * 2 - 10) / 2)
