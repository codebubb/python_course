# str = "i am loud"
# print(str.upper())

# lc = "I Should Be All Lowercase"
# uc = "I Should Be All Uppercase"
#
# print(lc.lower())
# print(uc.upper())

print("I Should Be All Uppercase".upper())
print("I Should Be All Lowercase".lower())
