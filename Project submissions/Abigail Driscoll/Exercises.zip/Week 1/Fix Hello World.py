print("Hello User")
print("Welcome to the corp network")
