# what do the different symbols do?

print(2 + 2)        # this adds 2 and 2
print(12 - 2)       # this subtracts 2 from 12
print(3 * 3)        # this multiplies 3 by 3
print(3 ** 3)       # this is 3 to the power of 3
print(12 / 3)       # this is 12 divided by 3
print(12 % 3)       # this finds the remainder of 12 divided by 3
