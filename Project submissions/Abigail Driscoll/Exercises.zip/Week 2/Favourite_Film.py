film = input("Please enter your favourite film: ")
print("Your favourite film is {}".format(film))