numberone = int(input("Please enter a number: "))
numbertwo = int(input("and another number: "))
answer = numberone * numbertwo
print("{} X {} = {}".format(numberone, numbertwo, answer))

