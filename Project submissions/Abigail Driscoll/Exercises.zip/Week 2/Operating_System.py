import os
print(os.environ["COMPUTERNAME"])
print(os.environ["OS"])
print(os.environ["SYSTEMROOT"])
print(os.environ["PROCESSOR_IDENTIFIER"])
print(os.environ["NUMBER_OF_PROCESSORS"])
print(os.environ["PYTHONPATH"])