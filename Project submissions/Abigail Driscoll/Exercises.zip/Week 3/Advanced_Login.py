Password = input("Please enter your password: ")
if Password == "password123":
    print("Your password is correct")
else:
    print("Your password is not correct")

