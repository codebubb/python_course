import tkinter
window = tkinter.Tk()
btn = tkinter.Button(window, text="Click Me!")
btn.pack(pady=30)
window.mainloop()