# timestable = int(input("Please enter the times table you would like to view: "))
# upTo = int(input("Please enter how many lines would you like to go up to: "))
# num = range(1,upTo+1)
# for num in range(1, upTo+1):
#     print (num, "x", timestable,"=", num * timestable)


timestable = int(input("Please enter the times table you would like to view: "))
upTo = int(input("Please enter how many lines would you like to go up to: "))
num = range(1,upTo+1)
for num in range(1, upTo+1):
    print (num, "x", timestable,"=", num * timestable)