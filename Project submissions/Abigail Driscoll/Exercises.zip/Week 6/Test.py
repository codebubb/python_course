import Useful_Module
Useful_Module.alength()