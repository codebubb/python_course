file = open('file.txt')
for r in file:
    file.sort()
    print(file)

#  UNFINISHED