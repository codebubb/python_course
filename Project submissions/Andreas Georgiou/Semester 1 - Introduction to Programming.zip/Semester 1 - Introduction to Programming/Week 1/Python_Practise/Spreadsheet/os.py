import os

os.system("touch hello.txt")
