a = range(1,100)

print range(1,100,10)


for i in range(12):
    print "hello"

for i in range(1,10):
    if i == 6:
        print " "
        continue
    print i
