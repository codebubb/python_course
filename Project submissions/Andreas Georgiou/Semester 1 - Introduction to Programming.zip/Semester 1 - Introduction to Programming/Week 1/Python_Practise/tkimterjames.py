import window

window = Tkinter.Tk()
btn = Tkinter.Button(window, text="clock me"
btn.pack(pady=30)
window.mainloop()
