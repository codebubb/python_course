import time

time.time()

print time.time()


import random

print random.random()*10

print random.randrange(10)
