Python 2.7.11 (v2.7.11:6d1b6a68f775, Dec  5 2015, 20:40:30) [MSC v.1500 64 bit (AMD64)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> print 2 + 2 # adds 2 and 2.
4
>>> print 12 - 2 # takes away 2 from 12.
10
>>> print 3 * 3 # multiplies 3 and 3.
9
>>> print 3 ** 3 # 3 to the power of 3.
27
>>> print 12 / 3 # 12 divided by 3
4
>>> print 12 % 3 # modulo gives us whatever is remaining after 12 has been divided by 3.
0
>>> 
