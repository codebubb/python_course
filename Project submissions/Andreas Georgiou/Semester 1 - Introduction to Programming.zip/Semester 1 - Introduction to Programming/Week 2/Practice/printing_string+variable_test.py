myName = "Andy"
myAge = 27
print "Hi my name is " + myName + " and I am " + str(myAge) + " years old."

