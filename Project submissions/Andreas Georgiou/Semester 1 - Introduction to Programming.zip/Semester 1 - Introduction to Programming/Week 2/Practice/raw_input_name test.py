print "Hi, what's your name?"
name = raw_input()
print "Hi, " + name + ". How are you today?"
