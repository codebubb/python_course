import Tkinter
window = Tkinter.Tk()
btn = Tkinter.Button(window, text="Click Me!")
btn.pack(pady=30)
window.mainloop()
