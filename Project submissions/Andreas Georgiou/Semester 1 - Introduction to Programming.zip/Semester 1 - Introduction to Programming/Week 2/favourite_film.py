fav_film = raw_input("Enter your favourite film: ")
print "So your favourite film is " + fav_film + "."
