subjects = ["Science", "Maths", "English", "IT"] # a list called subjects

print subjects[1] # prints index 1 from the list. index starts at 0
