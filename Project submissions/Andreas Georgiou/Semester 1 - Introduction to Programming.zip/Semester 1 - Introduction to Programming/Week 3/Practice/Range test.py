quick_list0 = range(10) # quickly creats a list ranging from 0-9 (which is 10 integers)

print quick_list0


quick_list1 = range(5,10) # creates a list from 5-9

print quick_list1

for lst in quick_list0: # print the list line by line using a for loop
    print lst
