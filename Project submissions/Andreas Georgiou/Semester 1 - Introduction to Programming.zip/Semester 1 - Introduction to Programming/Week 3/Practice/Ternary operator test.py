password = raw_input("Enter your password: ")

print "Login in..." if password == "letmein" else "Incorrect password"

# Ternary Operator is when the whole if statment is on one line (including the else).
