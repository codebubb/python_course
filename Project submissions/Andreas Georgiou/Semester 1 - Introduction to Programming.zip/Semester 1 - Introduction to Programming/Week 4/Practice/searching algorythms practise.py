# Linear search Algorythm

#As the name suggests, a linear search
#looks through every item in a list in turn until
#the desired item is found or until the search reaches the end of the list.


#--------------------------------------------------


# Binary search Algorythm

#A binary search can only be performed on a sorted
#list as it works by taking the middle element and then
#determining whether the value
#being searched will be in the lower half or top half of the list.

