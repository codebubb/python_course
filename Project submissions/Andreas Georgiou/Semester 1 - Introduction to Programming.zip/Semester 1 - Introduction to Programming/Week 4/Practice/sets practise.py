# a SET is a list that ONLY contains unique items.

# the set() fucntions processes a list and removes any duplicated items/values


phones = ["Samsung", "Apple", "HTC", "Apple", "Sony", "Microsoft Lumia",
          "LG", "Sony", "Apple", "Blackberry", "LG", "Apple"]

unique_phones = set(phones)

print phones
print unique_phones
