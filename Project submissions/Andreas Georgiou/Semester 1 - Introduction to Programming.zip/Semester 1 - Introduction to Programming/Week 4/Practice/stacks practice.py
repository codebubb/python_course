# a STACK is a data structure that can be described pretty much like a
# real life stack of items, like a stack of books.

# in programming a stack is describes as LAST IN, FIRST OUT, as only the top
# item can be accesed directly. using .append() and .pop()

tutors = ["Matt", "James", "Ronnie"]

tutors.append("Stuart")
a = tutors.pop(1)

print tutors
print a
