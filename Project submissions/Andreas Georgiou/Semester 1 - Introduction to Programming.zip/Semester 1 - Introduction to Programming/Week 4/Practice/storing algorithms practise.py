# Bubble sort Algorythm

#A bubble sort repeatedly goes through each of the values
#in a list and compares the value next to it to see which one is bigger.
#If the first value is larger than the
#second the values swap position in the list (assuming sorting ascending)

#ascending order in diffrent term.


#----------------------------------------------------



# Insertion sort Algorythm

#An insertion sort works by removing an item
#from the end of a list and working out where the value should
#fit into the list.
