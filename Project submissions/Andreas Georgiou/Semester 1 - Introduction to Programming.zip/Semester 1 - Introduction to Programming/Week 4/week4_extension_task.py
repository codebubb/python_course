numbers_list = [1, 20, 2 ,8 ,7 ,6 ,4 ,3, 9, 10, 0, 15,
                5, 18, 12, 13, 11, 14, 19, 16, 17]
print numbers_list
print ""

numbers_list.sort()

print numbers_list
