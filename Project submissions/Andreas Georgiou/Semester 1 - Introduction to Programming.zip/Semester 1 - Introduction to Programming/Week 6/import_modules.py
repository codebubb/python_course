print " -------------------------------------- "
print "|                                      |"
print "| WELCOME TO THE TEXT ANALYSIS PROGRAM |"
print "|                                      |"
print " -------------------------------------- "

print "Please login to complete the text analysis tests."
print ""

import encrypted_login
print "=========================================================================================="
import average_length
print "=========================================================================================="
import last_word
print "=========================================================================================="
import position_in_alphabet
