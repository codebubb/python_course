import pickle

filename = "passwordmd5.txt" # assigning a file to a variable

open_file = open(filename, "r") # opening a file 'to read in this case (r)'
print open_file()
open_file.close() #  closing the file
