import webbrowser

def open_url():
    webbrowser.open("http://wordcountertool.com/")

open_url()
