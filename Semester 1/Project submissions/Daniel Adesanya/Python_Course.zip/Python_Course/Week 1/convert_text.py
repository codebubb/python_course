Python 2.7.11 (v2.7.11:6d1b6a68f775, Dec  5 2015, 20:32:19) [MSC v.1500 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> print "I should Be all Uppecase".upper()
I SHOULD BE ALL UPPECASE
>>> print "I should Be all Lowercase.lower()
SyntaxError: EOL while scanning string literal
>>> print "I should Be all Lowercase".lower()
i should be all lowercase
>>> 
