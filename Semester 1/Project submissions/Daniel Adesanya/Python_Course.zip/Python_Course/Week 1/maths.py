Python 2.7.11 (v2.7.11:6d1b6a68f775, Dec  5 2015, 20:32:19) [MSC v.1500 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> print 2 + 2    # This adds it up
4
>>> print 12 - 2    # This subtracts
10
>>> print 3 * 3    # this multiplies stuff
9
>>> print 3 ** 3   # this finds 3 to the power of 3
27
>>> print 12 / 3   # this does division
4
>>> print 12 % 3   # It devides and shows the remainder
0
>>> 
