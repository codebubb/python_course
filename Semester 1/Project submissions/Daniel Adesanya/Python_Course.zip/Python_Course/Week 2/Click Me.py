myName = 'Daniel'
print 'Hi my name is' + myName

myName = 'Daniel'
myAge = 21
print 'Hi my name is ' + myName + ' and I am ' + str(myAge) + ' years old. '

livesleft = 3
print livesleft > 9


password = raw_input("Enter your password:")
print "Correct Password:" + str(password == "Letmein")
