firstname = raw_input("What is your firstname? ")
favouritefilm = raw_input("What is your favourite film? ")
print "Hello %s your favourite film is %s" %(firstname, favouritefilm)
