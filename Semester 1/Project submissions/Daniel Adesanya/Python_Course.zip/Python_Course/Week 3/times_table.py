for num in range(1,11):
    print num, "multipied by 7 = ", num * 7
    
