def say_hello(name = "Stranger"):
    print "Hello", name, "!"
