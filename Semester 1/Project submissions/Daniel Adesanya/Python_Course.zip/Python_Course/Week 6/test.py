def say_hello():
    print "Lee"
    exit()
