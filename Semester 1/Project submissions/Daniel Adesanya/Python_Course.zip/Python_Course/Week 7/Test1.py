import random

def pen():
    print random.randrange(10,9001)
    pen()
pen()
