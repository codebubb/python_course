print 2 + 10 * 2 - 10 /2 #The answer is 17. This is because of the rules 'BIDMAS'
