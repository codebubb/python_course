print 2 + 2    #Plus
print 12 - 2   #Subtract
print 3 * 3    #Multiply
print 3 ** 3   #To the power of
print 12 / 3   #Divide
print 12 % 3   #Remainder
