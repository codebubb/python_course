favourite_film = raw_input("What is your favourite film?")

print "Ah, so your favourite film is %s." % (favourite_film)
