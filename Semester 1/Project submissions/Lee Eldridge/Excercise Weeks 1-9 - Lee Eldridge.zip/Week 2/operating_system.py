import os
print os.environ["COMPUTERNAME"]
