def p(name):
    print "Hello", name+",", "how are you today?"

def g():
    for e in range(11):
        print e
