with open("numbers.txt", "r") as f:
    read = f.read()

print read
