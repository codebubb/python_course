import webbrowser

webbrowser.open("http://google.com")
