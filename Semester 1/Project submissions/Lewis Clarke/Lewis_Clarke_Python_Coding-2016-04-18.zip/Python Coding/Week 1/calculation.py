print 2+10*2-10/2

'''
python uses the math in the order it sees to be the most important
so first it uses 10/2 to get 5 then it multiplies 10*2 to get 20
then subtracts the 5 or adds the 2 or vice versa to get 17
'''

print ((2+10)*2 -10)/2
