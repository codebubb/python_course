print "I Should Be all Uppercase".upper()
print "I Should Be all Lowercase".lower()
