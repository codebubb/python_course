print ("Hello User")
print("Welcome to the corp network")
print 350 /4
