print 2+2   # This adds
print 12-2  # This Subtracts
print 3*3   # This Multiplys
print 3**3  # This is to the power of
print 12/3  # this is division
print 12%3  # this is Modulus, shows the remainder
