film = raw_input("What is your favourite film? ")
print ("Thanks, so your favourite film is %r ") % film
