print ("input 2 numbers below to add them together")
a = raw_input("Please input your first number ")
b = raw_input ("Please input your second number ")
print int(a) + int(b)
