num = 7
for x in range(1,11):
    print num,'x', x,  '=', num*x
