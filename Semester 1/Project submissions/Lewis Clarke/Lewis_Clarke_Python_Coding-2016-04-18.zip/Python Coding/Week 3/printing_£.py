# -*- coding: utf-8 -*-
print ("£2.30")
