customer = {'Ronnie Sullivan': '01234 567890',
'Marilyn Tucker':'01987 654321',
'Brad Bennett' :'01897 65320', 'Rodney White' :'020 765 6655',
'Brian Burton' : '01382 763999'}




customer.split()
