value = []
value.append('value 1')
print value
value.append('value2')
print value
value.pop()
print value
value.append('value 2')
print value
value.append('value 3')
print value
value.pop()
print value
value.pop() 
print value
value.append('value2')
print value
value.pop()
print value
