
def pick_a_sentance(string):
    x = string.split()
    print x[-1]
    
